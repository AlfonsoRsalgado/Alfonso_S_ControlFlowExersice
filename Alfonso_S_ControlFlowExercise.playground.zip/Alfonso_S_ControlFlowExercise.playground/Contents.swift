// 180 seconds is equal to 3 min
var endoftime = 180
//loop of ticks 60 sec equal one min
let minuets = 60
for _ in 0..<minuets {
    //render the tick mark each min (60 times)
}
//indication that 3 minuetes have passed
if endoftime == 180 {
    print ("3 minuets have passed.")
}
